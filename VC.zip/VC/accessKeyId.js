const accessKeyId = "AKIAQIIDXT4ZYAPFG7IT";
module.exports = accessKeyId;
